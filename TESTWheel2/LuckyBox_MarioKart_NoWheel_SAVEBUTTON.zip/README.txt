Lucky Box – Mario Kart Style (ohne Hintergrundrad)
====================================================
- Öffne die Datei: LuckyBox_MarioKart_NoWheel.html
- Kein Luckywheel im Hintergrund, nur die leuchtende „Item-Box“ mit deutlich sichtbarem weißem Fragezeichen.
- Gewinne per Text oder Bild, eigene Schrift (.ttf/.otf/.woff), Spin-/Win-Sound inkl. Lautstärke.
- Nach Gewinnanzeige blendet alles aus, bis zum nächsten Klick.
- Zufallsauswahl erfolgt beim Ausblenden der Box.

OBS-Hinweis:
- In OBS als „Browser“-Quelle die lokale Datei einbinden: file:///Pfad/zu/LuckyBox_MarioKart_NoWheel.html
  oder Bildschirm-/Fensteraufnahme nutzen.
